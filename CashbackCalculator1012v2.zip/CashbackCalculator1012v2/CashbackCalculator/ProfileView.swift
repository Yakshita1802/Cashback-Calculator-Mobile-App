//
//  ProfileView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/5/23.
//

import SwiftUI
import Firebase
import FirebaseFirestore


struct ProfileView: View {
    var body: some View {
        Text("Profile View")
            .font(.title)
            .padding()
    }
}

