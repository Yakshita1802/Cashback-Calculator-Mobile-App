//
//  CardView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/5/23.
//

import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore

struct CardView: View {
    @Binding var selectedBank: String
    @Binding var userWallet: [CardModel]
    @State private var selectedCard: String = ""
    @State private var isCardAdded: Bool = false
    @State private var isDuplicateCard: Bool = false
    @State private var alertMessage: String = ""
    @State private var showAlert: Bool = false

    // Dictionary to store available cards for different banks
    let availableCards: [String: [String]] = [
        "Chase": ["Chase Freedom Unlimited", "Chase Freedom", "Chase Slate", "Chase Sapphire Preferred", "Chase Sapphire Reserve", "Prime Visa"],
        "American Express": ["American Express Gold", "Delta SkyMiles Platinum", "Blue Cash Everyday", "Amex Platinum"],
        "Citi": ["Citi CashReturns", "Citi Double Cash", "Citi Simplicity", "Citi Premier"],
        // Add more cards for other banks as needed
    ]

    var body: some View {
        NavigationView {
            VStack {
                // Show the selected bank and card
                Text("Selected Bank: \(selectedBank)")
                    .font(.title)
                    .padding(.top, 20)

                Text("Selected Card: \(selectedCard)")
                    .font(.title)
                    .padding(.top, 10)

                Spacer()

                // Display a list of available cards to select from
                List(availableCards[selectedBank] ?? [], id: \.self) { card in
                    Button(action: {
                        selectedCard = card
                    }) {
                        Text(card)
                    }
                }
                .listStyle(GroupedListStyle())

                Button(action: {
                    // Add the selected card to the user's wallet
                    if !selectedCard.isEmpty {
                        // Check if the card is already in the wallet
                        if userWallet.contains(where: { $0.name == selectedCard && $0.issuer == selectedBank }) {
                            // Card is already in the wallet
                            alertMessage = "This card is already in your wallet."
                            showAlert = true
                        } else {
                            // Add the card to the user's wallet
                            addCardToUserWallet()
                        }
                    }
                }) {
                    Text("Add to Wallet")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(selectedCard.isEmpty ? Color.gray : Color.blue)
                        .cornerRadius(10)
                }
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }

                Spacer()

                List {
                    ForEach(userWallet, id: \.id) { card in
                        Text("\(card.name) - \(card.issuer)")
                    }
                }
                .listStyle(GroupedListStyle())
            }
            .padding()
            .navigationBarTitle("Select Card", displayMode: .inline)
        }
    }

    private func addCardToUserWallet() {
        FirestoreManager.shared.addCardToUserWallet(
            selectedBank: selectedBank,
            selectedCard: selectedCard,
            expirationDate: "",  // You can provide the actual values
            rewards: 0.0  // You can provide the actual values
        ) { error in
            if let error = error {
                alertMessage = "Failed to add the card to your wallet: \(error.localizedDescription)"
                showAlert = true
            } else {
                isCardAdded = true
                userWallet.append(CardModel(name: selectedCard, issuer: selectedBank, expirationDate: "", rewards: 0.0))
            }
        }
    }
}
