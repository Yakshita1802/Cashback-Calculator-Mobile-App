//
//  CardDetailView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/11/23.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth

struct CardDetailView: View {
    var card: CardModel

    var body: some View {
        VStack {
            Text("Card Details")
                .font(.title)

            Text("Name: \(card.name)")
            Text("Issuer: \(card.issuer)")

            if let expirationDate = card.expirationDate {
                Text("Expiration Date: \(expirationDate)")
            }

            if let rewards = card.rewards {
                Text("Rewards: \(rewards)")
            }

            // Add more Text views to display other card details
        }
    }

}
