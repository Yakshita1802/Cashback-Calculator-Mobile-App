//
//  CardModel.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/10/23.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth

struct CardModel: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let issuer: String
    var expirationDate: String? = nil
        var rewards: Double? = nil
    
}
