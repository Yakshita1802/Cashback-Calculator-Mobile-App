//
//  WalletView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/5/23.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth


struct WalletView: View {
    @State private var rewardBalance: Double = 0
    @State private var isAddCardViewPresented: Bool = false
    @State private var selectedBank: String = ""
    @State private var userWallet: [CardModel] = []
    @State private var currentPage = 0
    let imageNames = ["waves-crashing_N53IDRCMRC", "pexels-photo-4101555", "pexels-photo-4035587"] // Add image names

    var body: some View {
        NavigationView {
            VStack {
                TabView(selection: $currentPage) {
                    ForEach(0..<imageNames.count, id: \.self) { index in
                        Image(imageNames[index])
                            .resizable()
                            .scaledToFill()
                            .frame(height: 250) // Adjust the size as needed
                            .clipped()
                            .overlay(
                                Text("Rewards Balance $ \(rewardBalance)")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding()
                            )
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .frame(height: 250) // Adjust the height as needed

                Button(action: {
                    // Show AddCardView when the button is tapped
                    isAddCardViewPresented = true
                }) {
                    Text("Add Card")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(10)
                        .padding(.top, 20)
                }
                .sheet(isPresented: $isAddCardViewPresented) {
                    // Pass the selectedBank and userWallet to AddCardView
                    AddCardView(selectedBank: $selectedBank, userWallet: $userWallet)
                }

                Spacer()

                // Display added cards in the wallet and navigate to CardDetailView
                List(userWallet) { card in
                    NavigationLink(
                        destination: CardDetailView(card: card),
                        label: {
                            Text("\(card.name) - \(card.issuer)")
                        }
                    )
                }
                .listStyle(PlainListStyle()) // Use PlainListStyle for a simple list

                Spacer()

                HStack {
                    NavigationLink(
                        destination: WalletView(),
                        label: {
                            Text("Wallet")
                                .font(.title)
                                .foregroundColor(.blue)
                        }
                    )

                    Spacer()

                    NavigationLink(
                        destination: ProfileView(),
                        label: {
                            Text("Profile")
                                .font(.title)
                                .foregroundColor(.blue)
                        }
                    )
                }
                .padding()
            }
            .padding()
            .onAppear {
                let timer = Timer.scheduledTimer(withTimeInterval: 15, repeats: true) { _ in
                    withAnimation {
                        currentPage = (currentPage + 1) % imageNames.count
                    }
                }
                RunLoop.current.add(timer, forMode: .common)
            }
        }
    }
}

struct WalletView_Previews: PreviewProvider {
    static var previews: some View {
        WalletView()
    }
}
