import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth


struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isLoggedIn: Bool = false
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Login")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.top, 20)
                
                TextField("Email", text: $email)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button(action: {
                    // Implement Firebase login logic here
                    Auth.auth().signIn(withEmail: email, password: password) { _, error in
                        if let error = error {
                            // Handle the error and show an alert
                            showAlert = true
                            alertMessage = "Incorrect username or password. Please try again."
                        } else {
                            // Login successful, set isLoggedIn to true
                            isLoggedIn = true
                        }
                    }
                }) {
                    Text("Login")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(10)
                        .padding(.bottom, 20)
                }
                
                // Use NavigationLink to navigate to WalletView when isLoggedIn is true
                NavigationLink(
                    destination: WalletView(),
                    isActive: $isLoggedIn,
                    label: { EmptyView() }
                )
            }
            .padding()
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Alert"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }
}
