//
//  FirestoreManager.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/10/23.
//

import FirebaseFirestore
import FirebaseAuth
import Firebase

class FirestoreManager {
    static let shared = FirestoreManager()
    private let db = Firestore.firestore()
    
    private init() {}
    
    // Function to add a card to Firestore
    func addCardToFirestore(cardName: String, bankName: String, completion: @escaping (Error?) -> Void) {
        guard let user = Auth.auth().currentUser else {
            let error = NSError(domain: "YourAppDomain", code: 401, userInfo: [
                NSLocalizedDescriptionKey: "User not authenticated"
            ])
            completion(error)
            return
        }
        
        let cardsCollection = db.collection("cards")
        let cardData: [String: Any] = [
            "cardName": cardName,
            "bankName": bankName,
            "userId": user.uid
        ]
        
        cardsCollection.addDocument(data: cardData) { error in
            completion(error)
        }
    }
    
    // Function to add a card to a user's wallet in Firestore
    func addCardToUserWallet(selectedBank: String, selectedCard: String, expirationDate: String?, rewards: Double?, completion: @escaping (Error?) -> Void) {

        guard let user = Auth.auth().currentUser else {
            let error = NSError(domain: "YourAppDomain", code: 401, userInfo: [
                NSLocalizedDescriptionKey: "User not authenticated"
            ])
            completion(error)
            return
        }
        
        // Reference the user's document in Firestore
        let userDocRef = db.collection("Users").document(user.uid)
        
        // Reference the "Wallet" subcollection within the user's document
        let walletCollectionRef = userDocRef.collection("Wallet")
        
        // Check if the card is already in the user's wallet
        walletCollectionRef.whereField("Name", isEqualTo: selectedCard).whereField("Issuer", isEqualTo: selectedBank)
            .getDocuments { (querySnapshot, error) in
                if let error = error {
                    completion(error)
                    return
                }
                if let document = querySnapshot?.documents.first {
                    // The card already exists in the wallet
                    let duplicateCardError = NSError(domain: "YourAppDomain", code: 409, userInfo: [
                        NSLocalizedDescriptionKey: "Card already in wallet"
                    ])
                    completion(duplicateCardError)
                } else {
                    // Card is not in the wallet, so add it
                    let cardData: [String: Any] = [
                        "Name": selectedCard,
                        "Issuer": selectedBank
                        // Add other card properties as needed
                    ]
                    walletCollectionRef.addDocument(data: cardData) { error in
                        completion(error)
                    }
                }
            }
    }
    
    func saveWalletToFirestore(_ user: User, wallet: [CardModel], completion: @escaping (Error?) -> Void) {
        // Create a Firestore reference to the user's wallet data
        let walletRef = db.collection("Users").document(user.uid).collection("Wallet")

        // Remove existing data before saving to avoid duplicates (optional)
        walletRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                completion(error)
                return
            }
            
            for document in querySnapshot?.documents ?? [] {
                document.reference.delete()
            }
            
            // Save the updated wallet data
            for card in wallet {
                walletRef.addDocument(data: [
                    "name": card.name,
                    "issuer": card.issuer
                ])
            }
            completion(nil)
        }
    }

    func retrieveWalletFromFirestore(_ user: User, completion: @escaping ([CardModel]?, Error?) -> Void) {
        let userUID = user.uid
        let walletCollection = db.collection("Users").document(userUID).collection("Wallet")
        
        walletCollection.getDocuments { (querySnapshot, error) in
            if let error = error {
                completion(nil, error)
            } else {
                var wallet: [CardModel] = []
                for document in querySnapshot!.documents {
                    if let cardData = document.data() as? [String: Any],
                        let name = cardData["Name"] as? String,
                        let issuer = cardData["Issuer"] as? String,
                        let expirationDate = cardData["ExpirationDate"] as? String,
                        let rewards = cardData["Rewards"] as? Int {
                        // Convert rewards to Double
                        let rewardsAsDouble = Double(rewards)
                        
                        let card = CardModel(name: name, issuer: issuer, expirationDate: expirationDate, rewards: rewardsAsDouble)
                        wallet.append(card)
                    }
                }


                completion(wallet, nil)
            }
        }
    }


}
