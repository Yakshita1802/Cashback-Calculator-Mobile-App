//
//  CashbackCalculatorApp.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/4/23.
//

import SwiftUI
import Firebase

@main
struct CashbackCalculatorApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
