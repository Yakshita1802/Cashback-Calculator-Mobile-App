//
//  ContentView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/4/23.
//

import SwiftUI
import Firebase

struct ContentView: View {
    var body: some View {
        NavigationView {
            // Use ZStack to overlay the linear gradient on the entire background
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.purple, Color.white]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack {
                    // Your content here
                    Text("Welcome")
                        .font(.largeTitle)  // Increase the font size
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)  // Increase the top padding

                    Text("Cashback Calculator")
                        .font(.largeTitle)  // Increase the font size
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top, 10)  // Increase the top padding

                    Spacer()

                    NavigationLink(destination: LoginView()) {
                        Text("Login")
                            .font(.title)
                            .foregroundColor(.white)
                            .frame(width: 200, height: 50)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(10)
                            .padding(.bottom, 20)
                    }

                    NavigationLink(destination: SignupView()) {
                        Text("Signup")
                            .font(.title)
                            .foregroundColor(.white)
                            .frame(width: 200, height: 50)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(10)
                            .padding(.bottom, 20)
                    }
                }
                .padding()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



