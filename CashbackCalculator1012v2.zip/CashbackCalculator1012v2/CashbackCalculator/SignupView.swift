//
//  SignuoView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/4/23.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth


struct SignupView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var signupSuccess: Bool = false
    @State private var signupErrorMessage: String = ""
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Signup")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.top, 20)
                
                TextField("Email", text: $email)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button(action: {
                    Auth.auth().createUser(withEmail: email, password: password) { result, error in
                        if let error = error {
                            // Handle the error and set the error message
                            signupErrorMessage = "Error creating user: \(error.localizedDescription)"
                        } else {
                            // Signup successful, set signupSuccess to true
                            signupSuccess = true
                        }
                    }
                }) {
                    Text("Signup")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(10)
                        .padding(.top, 20)
                }
                
                // Display success message if signup was successful
                if signupSuccess {
                    Text("Signup successful!")
                        .foregroundColor(.green)
                }
                
                // Display error message if there was an error
                if !signupErrorMessage.isEmpty {
                    Text(signupErrorMessage)
                        .foregroundColor(.red)
                }
                
                Spacer()
                
                NavigationLink(destination: LoginView(), isActive: $signupSuccess) {
                    EmptyView()
                }
                
                NavigationLink(destination: LoginView()) {
                    Text("Already have an account?")
                        .font(.footnote)
                        .foregroundColor(.black)
                    Text("Login")
                        .font(.footnote)
                        .foregroundColor(.blue)
                }
            }
            .padding()
        }
    }
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
    }
}
