//
//  PageView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/13/23.
//
import SwiftUI

struct PageView<Content: View>: View {
    var content: Content
    @State private var currentPage: Int = 0
    private let pageCount: Int

    init(_ pageCount: Int, @ViewBuilder content: () -> Content) {
        self.pageCount = pageCount
        self.content = content()
    }

    var body: some View {
        TabView(selection: $currentPage) {
            content
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .tag(0)
            ForEach(1..<pageCount) { index in
                content
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .tag(index)
            }
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
    }
}
