//
//  AddCardView.swift
//  CashbackCalculator
//
//  Created by Yakshita Rakholiya on 10/5/23.
//

import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore




struct AddCardView: View {
    @Binding var selectedBank: String
    @Binding var userWallet: [CardModel]
    @State private var isCardViewPresented: Bool = false
    @State private var searchText: String = ""
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""

    // Dictionary that maps bank names to image names
    let bankImages: [String: String] = [
        "Chase": "60394399d4d69e00040ae03d",
        "Citi": "Citi.svg",
        "Discover": "png-transparent-discover-card-discover-financial-services-credit-card-savings-account-bank-credit-card-text-orange-logo",
        "American Express": "amex-american-express-logo-8AA7F1A998-seeklogo.com",
        "Capital One": "Capital-One-Logo",
        "Bank of America": "Bank-of-America-Emblem",
        "Goldman Sachs": "Goldman_Sachs-Logo.wine",
        "Wells Fargo": "Wells_Fargo-Logo.wine",
        // Add entries for other banks as needed
    ]

    // List of available banks
    let availableBanks = [
        "Chase", "American Express", "Citi", "Capital One", "Discover",
                "Bank of America", "Goldman Sachs", "Wells Fargo", // Add more banks here
    ]

    var body: some View {
        NavigationView {
            VStack {
                TextField("Search Bank", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                List(availableBanks.filter { searchText.isEmpty ? true : $0.localizedCaseInsensitiveContains(searchText) }, id: \.self) { bank in
                    Button(action: {
                        selectedBank = bank

                        // Check if the selected card already exists in the wallet
                        if userWallet.contains(where: { $0.name == bank }) {
                            alertMessage = "Card is already in your wallet."
                            showAlert = true
                        } else {
                            isCardViewPresented.toggle()
                        }
                    }) {
                        HStack {
                            // Display the bank image on the left
                            if let imageName = bankImages[bank] {
                                Image(imageName) // Assuming the image names match your asset catalog
                                    .resizable()
                                    .frame(width: 40, height: 40) // Adjust the size as needed
                                    .aspectRatio(contentMode: .fit)
                            }

                            // Display the bank name
                            Text(bank)
                        }
                    }
                }
                .listStyle(GroupedListStyle())

                NavigationLink(destination: CardView(selectedBank: $selectedBank, userWallet: $userWallet), isActive: $isCardViewPresented) {
                    EmptyView()
                }
            }
            .navigationBarTitle("Select Bank", displayMode: .inline)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Alert"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }
}
